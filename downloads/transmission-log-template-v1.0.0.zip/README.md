# From the Poziverse — Blog + Media Center (V3.1, Phase 4)

A design-showpiece blog and growing media center for **Eric Poziverse** — an AI futurist's field notes from the edge of the AI frontier. Static site: no server needed to run it, zero external dependencies on the home page.

## Version history

- **V1** — initial blog (archived: `../archive/from-the-poziverse-v1/`)
- **V2** — content deepened from the vault, About page, RSS, deep links, robustness hardening (archived: `../archive/from-the-poziverse-v2/`)
- **V2.1** — index.html made fully self-contained (inline CSS/JS/data/fonts) after embedded-preview breakage
- **V3 (Phase 3)** — **Broadcast strip** (honest snapshot cards for YouTube / Instagram / X / TikTok, dated `AS OF` stamps, never live widgets) · **Watch page** (`watch.html`: Field Reports with facade-player machinery, run-of-show rail, transcript tab, twin-transmission panel) · **FR-001** entry in a designed IN PRODUCTION state until the real video id lands · `socials[]` / `videos[]` data model · Watch in nav + social links in all footers · **build workflow switch**: `index.template.html` is now the canonical home template
- **V3.1 (Phase 4)** — **Reply Threads** (`replies.html`): the public-peer-review surface with the 7-beat format made visible (Pick / Claim / Praise / Divergence / Receipt / Handoff / Thread storyboard), fairness-gate ethical strip, episode bench with honest IN COMPOSITION states, and the `REPLIES[]` data model — drop a nominated creator + video into `data.js` and the episode renders

## Run it

Open **`index.html`** in any modern browser — no server needed. Optional local server:

```bash
cd from-the-poziverse
python -m http.server 8080
# then open http://localhost:8080
```

## What's inside

| File | Purpose |
|---|---|
| `index.html` | Self-contained home: hero + Broadcast strip + featured transmission + asymmetric archive grid + topic clusters + marquee + newsletter. **Generated — do not edit directly.** |
| `index.template.html` | **The canonical home template.** Edit this, then run `node ../.cluster/build.js` to regenerate `index.html`. |
| `watch.html` | Field Reports page — renders from `VIDEOS[]` in `data.js`; facade player activates when a video goes live |
| `replies.html` | Reply Threads — the 7-beat public-peer-review surface; renders from `REPLIES[]` |
| `article.html` | Article template — renders from `ARTICLES[]` via `?id=<slug>` |
| `about.html` | About the operator: story, four hosts, philosophy, projects |
| `feed.xml` | RSS 2.0 feed (articles) |
| `assets/css/style.css` | Design system: tokens (dark + light), typography, components, art signatures, broadcast/watch styles, print styles |
| `assets/js/data.js` | **The content file** — 12 articles + `SOCIALS[]` + `VIDEOS[]` + `CATEGORIES` |
| `assets/js/main.js` | Interactivity: theme, starfield, search/filter, reveals, tilt, newsletter, reading progress, broadcast/watch renderers |
| `assets/fonts/` | Vendored woff2 fonts (Instrument Serif, Schibsted Grotesk, JetBrains Mono) |

## Modify guide

| You want to… | Edit |
|---|---|
| Change articles / add one | `assets/js/data.js` → `ARTICLES[]`, then `node ../.cluster/build.js` |
| **Go live on a video** | `data.js` → `VIDEOS[]`: set `youtubeId` to the real id + `status: "live"`. Watch flips from IN PRODUCTION to the working player automatically |
| **Go live on a Reply Thread** | `data.js` → `REPLIES[]`: fill `creator`, `video`, the 7 `beats`, and flip `status: "live"`. The storyboard becomes the published episode |
| Colors / fonts / spacing | `style.css` tokens (`:root` dark, `[data-theme='light']` light), then rebuild |
| Home structure (nav/sections/footer) | `index.template.html`, then rebuild |
| Search / animations | `assets/js/main.js` (`bindSearch`, `bindReveals`, `bindTilt`, canvas block) |
| RSS after content changes | `node ../.cluster/gen-feed.js` |
| Swap in real images | Replace `.art-inner` blocks in `main.js` renderers with `<img>` tags (keep `alt`) |

## Quality coverage

- Responsive: 1440 / 1024 / 640 breakpoints on every page; grid collapses; touch targets ≥ 40px
- States: default/hover/focus/active/disabled on all controls; search empty state; newsletter error+success; IN PRODUCTION / RESERVED / CLOSED-MESH honest states per the blueprint
- Dark/light themes: token swap + View Transitions + localStorage persistence
- Motion: staggered reveals, tilt, marquee, pulse dots, starfield + meteors, signal sweep — all reduced or removed under `prefers-reduced-motion`
- Accessibility: landmarks, focus-visible rings, aria-pressed/live/label, contrast ≥ 4.5:1, transcripts planned for all Field Reports
- Encoding: all files UTF-8 clean (verified — no replacement characters)

## Content

12 articles from the Poziverse vault (real topics, vault-grounded short bodies). FR-001 is the planned video twin of the flagship transmission — drop the real `youtubeId` into `data.js` when it ships.
