/* ============================================================
   FROM THE POZIVERSE — Article index (V2, content deepened)
   Real topics + source material drawn from the Poziverse vault
   (Obsidian, 5,500+ notes). Edit this file to change titles,
   bodies, tags, or to add articles.
   ============================================================ */
window.POZIVERSE = window.POZIVERSE || {};

window.POZIVERSE.ARTICLES = [
  {
    slug: 'year-of-the-mesh',
    title: 'A Year of Building the <em>Poziverse Mesh</em>',
    deck: 'Four hosts, a seventeen-device tailnet, and a small fleet of agents that now run the boring parts of my life. What the first year taught me about infrastructure as a creative act.',
    category: 'Signal',
    tags: ['mesh', 'infrastructure', 'proxiverse', 'retrospective'],
    date: '2026-08-12',
    readTime: 8,
    glyph: '01',
    art: 'art-1',
    featured: true,
    excerpt: 'Four hosts, one tailnet, a fleet of agents. Twelve months of the Proxiverse mesh, in one field report.',
    body: `
      <p>Twelve months ago I wrote the document that started all of this — the system overview that asked a deceptively simple question: <em>what is this system, and where does everything live?</em> The answer turned out to be a mesh: four hosts, a seventeen-device Tailscale overlay, twenty-six LXCs on Proxmox, and a growing cast of agents that treat each other as infrastructure.</p>
      <p>The first lesson was that a personal infrastructure stack is a creative medium, not a utility bill. When the dashboard, the vault, the cron jobs, and the model routers are all yours, every decision is an aesthetic decision. Uptime becomes typography. Backups become rhythm.</p>
      <h2>The four hosts</h2>
      <p>The entire compute footprint fits on a small table:</p>
      <figure class="stat-row">
        <div class="stat"><div class="value">26</div><div class="label">LXCs on Proxmox</div></div>
        <div class="stat"><div class="value">15</div><div class="label">Always-on services</div></div>
        <div class="stat"><div class="value">17</div><div class="label">Devices on tailnet</div></div>
      </figure>
      <ul>
        <li><strong>Proxmox</strong> — the cluster tier. 26 containers, ~15 always-on: n8n, Pulse monitoring, the OIDC issuer, backups, the memory store.</li>
        <li><strong>WSL2 "Brain"</strong> — the agent substrate. 21 MCP servers, 28 cron jobs, 35+ skills, and the full Hermes state.</li>
        <li><strong>Windows workstation</strong> — where the desktop client and browser CDP live.</li>
        <li><strong>ZimaCube</strong> — the cortex tier: 30+ Docker containers and the sub-VM fleet (currently resting).</li>
      </ul>
      <blockquote>The mesh is not a server farm. It is a studio with a heartbeat.</blockquote>
      <h2>What the year changed</h2>
      <p>The single biggest shift: writing runbooks for the machine instead of for myself. Every fix became a note, every note became a script, and eventually the agents stopped needing me for the tasks I used to dread. A WireGuard fallback now survives Tailscale control-plane outages; a watchdog catches silent quota exhaustion before it bites; the vault versions every decision.</p>
      <p>There is no customer and no team — it is one person and his agents, on a closed network, doing the most interesting infrastructure project I know: making the system maintain itself so the evenings stay free for making things. Year two starts now.</p>
    `
  },
  {
    slug: 'agent-native-video',
    title: 'The Agent-Native Video Stack: Manim, HyperFrames, and the <em>New Render Pipeline</em>',
    deck: 'Programmatic animation engines are turning AI coding agents into video directors. The 2026 blueprint: four engines, three design-vocabulary skills, and one workflow that produces finished footage from a natural-language prompt.',
    category: 'Creation',
    tags: ['manim', 'hyperframes', 'remotion', 'video', 'agents'],
    date: '2026-08-04',
    readTime: 7,
    glyph: '02',
    art: 'art-2',
    excerpt: 'Four engines, three design-vocabulary skills, one workflow — the blueprint for agent-native visual production.',
    body: `
      <p>There is a stack emerging for what I call <strong>agent-native visual production</strong>: video made by AI coding agents driving programmatic animation engines — no keyframes clicked by hand, no timeline scrubbed. The blueprint lives in the vault under the 2026 visual-production mission, and its one-sentence goal is simple: equip the content business so that <em>any agent in the mesh can produce professional visual content from a natural-language prompt</em>.</p>
      <h2>The four-engine landscape</h2>
      <ul>
        <li><strong>Manim</strong> — mathematical and technical precision. Declarative scenes that are unbeatable when the shot is about a theorem or a system diagram.</li>
        <li><strong>HyperFrames</strong> — HTML, CSS, and GSAP rendered to MP4. Agent-native by construction: the same language the agent already writes.</li>
        <li><strong>Remotion</strong> — React as a video language. TypeScript-native, componentized, testable like any UI.</li>
        <li><strong>Motion Canvas</strong> — generator functions and a canvas API for technical storytelling.</li>
      </ul>
      <h2>The quality layer nobody talks about</h2>
      <p>The engine is only half the stack. The blueprint's real thesis: <em>the distinguishing factor between generic AI output and professional content is not the generation model — it is the design-vocabulary layer.</em> Three skills carry that layer: Anthropic's frontend-design for bold aesthetic direction, Impeccable for its codified anti-pattern detectors, and the LottieFiles motion-design skill for real animation craft. Great design prompts require design vocabulary; most people — and most agents — do not have it.</p>
      <blockquote>The render loop becomes a compiler. Feedback cycles shrink from days to minutes.</blockquote>
      <h2>The surrounding ecosystem</h2>
      <p>Around the engines sits an MCP ecosystem of 4,500+ servers. Six are priority for this stack: yutu (upload), ElevenLabs (voice), the Manim MCP, the Rive MCP, Firecrawl (research), and Brave Search. And the platform question is increasingly OpenClaw — 210k+ stars, 5,700+ skills on ClawHub — running alongside Hermes rather than instead of it. The pipeline: plan the scene, get human approval, render, synthesize voice, stitch, repurpose, upload. Seven steps, zero manual keyframing.</p>
    `
  },
  {
    slug: 'inside-glassy',
    title: 'Inside Glassy: A Local-First PKM With a <em>Design Language</em>',
    deck: 'SQLite storage, eight themes, WebGPU Whisper, an Obsidian bridge — and a brand spec so complete it ships as a system prompt. The story of building a neurodiversity-focused workspace that treats design as a feature, not a skin.',
    category: 'Product',
    tags: ['glassy', 'sqlite', 'design-system', 'local-first', 'pkm'],
    date: '2026-07-28',
    readTime: 7,
    glyph: '03',
    art: 'art-3',
    excerpt: 'A brand spec that ships as a system prompt: Glassy\u2019s neurodiversity-first design language, from tokens to daily pipeline.',
    body: `
      <p>Glassy started as a personal knowledge tool and became a small argument about design: that a local-first app should feel like a calm, beautiful workspace — not a spreadsheet with a dark mode bolted on. The core is deliberately boring — SQLite on disk, your notes in a file you own, nothing in the cloud — but the surface is anything but.</p>
      <h2>Design for neurodiversity</h2>
      <p>The brand spec in the vault is drop-in ready, and it is explicit about its audience: a neurodiversity-focused AI workspace. That constraint produces the design principles, and the principles are unusually concrete:</p>
      <ul>
        <li><strong>High contrast</strong> — WCAG AA minimum, preferring AAA.</li>
        <li><strong>Calm motion</strong> — no fast flashes; ease-out enters; stagger entries 40ms apart.</li>
        <li><strong>Generous whitespace</strong> — cognitive-load reduction as a first-class requirement.</li>
        <li><strong>Two typefaces max</strong> — display headlines, clear body, never more.</li>
      </ul>
      <p>The tokens are shipped as both hex and OKLCH — a deep dark background, a layered panel surface, a brand primary that passes AA at exactly 4.50:1 with zero safety margin, and a coral accent for emphasis. When the palette is this specific, every artifact matches, from a Manim scene to an HTML page.</p>
      <blockquote>The privacy story is not a feature list. It is a design constraint that makes everything else more interesting.</blockquote>
      <h2>The pipeline as a product</h2>
      <p>Glassy's content pipeline is part of the spec too: plan the scenes and palette, get mandatory human approval, render in Manim or HyperFrames, synthesize voice, stitch with FFmpeg, repurpose with Opus Clip, upload with yutu. The local-first guarantees hold throughout — WebGPU Whisper transcribes speech in the browser on your GPU, and the audio never leaves the machine. Local-first and beautiful are not in tension; when you cannot lean on the cloud, you learn to lean on craft.</p>
    `
  },
  {
    slug: 'llm-routing-mesh',
    title: 'Routing LLMs Across the Mesh: A <em>Field Guide</em>',
    deck: 'The actual routing topology behind the mesh: Ollama for interactive chat, LiteLLM as the hub, MiniMax for scheduled jobs — and the failover chain that keeps everything alive when quotas go quiet.',
    category: 'Systems',
    tags: ['llm', 'litellm', 'routing', 'ollama', 'minimax'],
    date: '2026-07-20',
    readTime: 6,
    glyph: '04',
    art: 'art-4',
    excerpt: 'The real topology: who serves what, the failover chain, and the lessons learned when cloud quotas die silently.',
    body: `
      <p>Once you run more than one model, you stop asking <em>which model is best</em> and start asking <em>which model is best for this</em>. That is the whole discipline of LLM routing, and on the mesh it is a literal routing table — small, boring, and load-bearing.</p>
      <h2>The topology</h2>
      <ul>
        <li><strong>CT 207 → Ollama Cloud</strong> — interactive chat, when the account has quota.</li>
        <li><strong>CT 123 → LiteLLM proxy</strong> — the hub for everything else; one endpoint, many backends.</li>
        <li><strong>CT 122 → Ollama local</strong> — native API plus local models; slow but always works.</li>
        <li><strong>CT 207 cron → MiniMax OAuth</strong> — scheduled jobs, via the MiniMax-M3 cron pattern.</li>
      </ul>
      <h2>The rules that keep it honest</h2>
      <pre><code># provider rules (from the runbook)
- minimax-m3:
    interactive: provider: minimax-oauth
    cron:        custom_providers: [minimax] + MINIMAX_API_KEY
    base_url:    https://api.minimax.io/anthropic
- NEVER route cron M3 jobs through ollama-cloud
  (quota exhaustion incident: 2026-07-25)
- failover chain:
    1. LiteLLM (CT 123)   — most models
    2. Ollama Cloud (CT 207) — interactive quota
    3. Ollama local (CT 122) — always works</code></pre>
      <blockquote>The proxy is the one place where your infrastructure can have opinions.</blockquote>
      <h2>What the incidents taught us</h2>
      <p>Three lessons, all paid for in real downtime. <strong>Cloud quota exhaustion is silent</strong> — 429s with no explicit error, which is exactly why a cron watchdog polls every fifteen minutes. <strong>Never redeploy a proxy when a healthy one already serves the same surface.</strong> And <strong>use the device-code flow for interactive OAuth, static keys for cron.</strong> The long game is a cost profile per agent — a ledger of tokens burned per task type, so the routing table keeps learning. That is the difference between running models and running a model economy.</p>
    `
  },
  {
    slug: 'hermes-always-on',
    title: 'Hermes, the Always-On Agent: Architecture and <em>Hard-Won Lessons</em>',
    deck: 'A desktop agent that minds 15 cron jobs, watches the vault, and files the changelog while I sleep. The cron-and-watchdog pattern, the silent-failure traps, and what keeps breaking.',
    category: 'Agents',
    tags: ['hermes', 'agents', 'cron', 'mcp', 'automation'],
    date: '2026-07-12',
    readTime: 7,
    glyph: '05',
    art: 'art-5',
    excerpt: 'Fifteen cron jobs, three job modes, one watchdog pattern — the always-on agent, dissected.',
    body: `
      <p>Hermes is what happens when you give an agent a schedule and a workspace and let it build a routine. The architecture is deliberately boring: the Hermes gateway is the cron scheduler — WSL2 has no system cron, so everything fires from the gateway process. Fifteen jobs, verified weekly, each in one of three modes.</p>
      <h2>Three job modes</h2>
      <ul>
        <li><strong>Agent mode</strong> (default) — the LLM runs the prompt on schedule. The morning briefing, the Poziverse audit.</li>
        <li><strong>Script mode</strong> — runs a script, returns its stdout. For jobs where a model adds nothing.</li>
        <li><strong>No-agent mode</strong> — the script <em>is</em> the job and stdout is delivered verbatim. This is how watchdogs run.</li>
      </ul>
      <h2>The watchdog pattern</h2>
      <pre><code># silent-watchdog contract
1. Script runs every N minutes
2. Empty stdout  = nothing to report (silence is health)
3. Non-empty stdout = message delivered (quota hit, drift found)
4. Non-zero exit = alert (a broken watchdog is never silent)</code></pre>
      <p>The Quota Watchdog polls every fifteen minutes because cloud quota exhaustion is silent — by the time cron jobs start 429ing, you are already late. Log rotation runs the same way. The pattern converts "is everything fine?" from a question you ask into a stream you subscribe to.</p>
      <blockquote>An agent's memory is only as good as its discipline. The vault is the discipline.</blockquote>
      <h2>What keeps breaking</h2>
      <p>The honest list from the session logs: the gateway itself is the single point of failure — without it, no cron, no watchdog, no repair jobs fire; WSL2 needs a start script after reboot; an assignee set to anything but "default" leaves tasks sitting in "ready" forever; and shell-producing code eats you on f-string backslashes unless you use raw strings. Each failure became a runbook line, and the runbook became the memory.</p>
    `
  },
  {
    slug: 'mission-control',
    title: 'Mission Control: Designing a Command Surface for an <em>Agent Fleet</em>',
    deck: 'The iframe-shell SPA that runs a one-person operations floor — kanban, cron, vault, and nine proxied services behind one calm interface. Plus the invariants that keep it from rotting.',
    category: 'Agents',
    tags: ['mission-control', 'dashboard', 'design', 'daily-driver'],
    date: '2026-06-30',
    readTime: 6,
    glyph: '06',
    art: 'art-6',
    excerpt: 'The iframe-shell SPA at the top of every day: six topnav buttons, auto-rendered zones, nine viewports, zero rot.',
    body: `
      <p>Mission Control is the iframe-shell SPA that sits at the top of my day — a single page that aggregates the kanban board, the cron jobs, the vault, and nine proxied mesh services: Gitea, Beszel, Calendar, Pulse, Herdr, OpenWebUI, and the rest. It is the closest thing the Poziverse has to an operations floor.</p>
      <h2>The composition</h2>
      <ul>
        <li><strong>Topnav</strong> — six buttons: Kanban, Schedule, Content Library, Knowledge Graph, Mindscape, Utility. No more, no less.</li>
        <li><strong>Sidebar</strong> — zones and services, auto-rendered from config; the utility dropdown carries mesh health, open tasks, recent activity, and system locks.</li>
        <li><strong>Viewports grid</strong> — nine icon-only iframe links in a 5-column grid that collapses 4/3/1 across breakpoints.</li>
      </ul>
      <h2>The invariants that keep it alive</h2>
      <p>Dashboards rot. Mission Control fights that with three hard rules: the Chrome (HTML shell) is locked — 17 files, MD5-verified daily, surgical patches only; every deploy goes to both live locations, because Caddy and the dashboard server serve different copies; and iframe proxies use a raw WebSocket handler, because generic proxies cannot proxy WebSockets.</p>
      <blockquote>A command surface should feel like a cockpit: everything you need, nothing you have to search for.</blockquote>
      <h2>Surfaces, not widgets</h2>
      <p>The design principle that survives contact: Mission Control is a <em>shell</em>, not a reimplementation. Each surface — kanban, atlas, the knowledge graph — ships and improves independently, and the dashboard just orchestrates the frames. When the Atlas notebook reader landed, it joined as another surface in an afternoon. Green means nothing happened, which is the best news an operations floor can deliver.</p>
    `
  },
  {
    slug: 'openmontage',
    title: 'OpenMontage: The First Open-Source <em>Agentic Video Studio</em>',
    deck: 'No Python orchestrator — the LLM agent IS the control plane. One hundred-plus tools, twelve production pipelines, and quality gates that treat editing like a build system.',
    category: 'Creation',
    tags: ['openmontage', 'video', 'agents', 'open-source'],
    date: '2026-06-18',
    readTime: 7,
    glyph: '07',
    art: 'art-7',
    excerpt: 'The agent is the control plane: 100+ tools, 12 pipelines, quality gates, budget governance — inside OpenMontage.',
    body: `
      <p>OpenMontage is the first open-source, agentic video production system — and its premise is a little radical: <strong>the LLM agent is the control plane; Python provides tools and persistence only.</strong> No orchestrator script, no pipeline framework. An AI coding assistant (Claude Code, Cursor, Hermes — pick yours) reads a pipeline manifest, reads a stage-director skill, calls the tools, self-reviews, checkpoints, and hands each stage to a human approval gate.</p>
      <h2>One hundred tools, three layers</h2>
      <p>The toolchain is organized as a three-layer knowledge architecture: <em>what exists</em> (100+ tools and 12 pipeline manifests in <code>tools/</code>), <em>how to use it</em> (conventions and quality bars in <code>skills/</code>), and <em>how it works</em> (82 deep technology knowledge packs in <code>.agents/skills/</code>). Every tool declares its agent-skills links, so the agent can walk from "what's available" to "how to do this well" in one hop.</p>
      <h2>Governance is the product</h2>
      <p>The interesting part is what keeps quality from collapsing: a tool registry with auto-discovery; multi-provider selectors that score options across seven dimensions; a cost tracker that estimates, reserves, and reconciles budget per shot; and a runtime that is <em>locked at proposal time</em> — Remotion for animated scenes, HyperFrames for kinetic type, FFmpeg for cuts — and cannot be silently swapped. Pre-compose validation blocks renders that would violate the delivery promise; a slideshow-risk scorer runs six-dimensional analysis before anything ships; post-render, ffprobe validates the actual file.</p>
      <blockquote>When editing becomes a build system, the render is just a compile step.</blockquote>
      <p>The bet is that agent-native video will evolve the way developer tooling did: through public, composable pieces rather than walled gardens. The boring part of video production is about to get automated, which means the fun part is about to get bigger.</p>
    `
  },
  {
    slug: 'youtube-creator-stack',
    title: 'The 2026 Creator Stack: Tools We Actually <em>Run</em>',
    deck: 'Five layers, sixty-plus tools scored against one stack profile, ten creator archetypes, and a lean-start stack that costs about $85 a month. The blueprint that keeps the first channel from trial-and-error.',
    category: 'Creation',
    tags: ['youtube', 'creator', 'stack', 'content', '2026'],
    date: '2026-05-25',
    readTime: 6,
    glyph: '08',
    art: 'art-8',
    excerpt: 'Five layers, 60+ tools scored, 10 archetypes, a ~$85/mo lean start — the decisive creator stack map.',
    body: `
      <p>The creator-stack blueprint exists for one reason: to make the content business <em>operationally aware</em> of the 2026 tool landscape before the first channel, newsletter, and pipeline ship — not by trial-and-error over six months. Its charter is blunt about scope: this blueprint supplies; it does not publish.</p>
      <h2>The five layers</h2>
      <ul>
        <li><strong>Pre-production</strong> — research, scripting, and the vault as the outline engine.</li>
        <li><strong>Production</strong> — capture, voice, and the animation stack (HyperFrames, Manim, Rive).</li>
        <li><strong>Post-production</strong> — stitch, repurpose, subtitle, localize.</li>
        <li><strong>Distribution</strong> — the newsletter as the primary surface, video as the amplifier.</li>
        <li><strong>Business operations</strong> — the analytics and ownership layer underneath it all.</li>
      </ul>
      <h2>Decisive, not comprehensive</h2>
      <p>Sixty-plus tools were surveyed and scored against the Poziverse stack profile, and roughly twenty were explicitly marked <em>anti-stack</em> — Notion, Hootsuite, ClickUp and friends. The blueprint's stated goal is worth quoting: <em>we are not trying to be comprehensive; we are trying to be decisive.</em> Ten creator archetypes were mapped so the first channel can copy a working pattern instead of inventing one, and two fully-automated pipeline patterns emerged: open-source Python, and n8n plus commercial APIs.</p>
      <blockquote>Do not build a content pipeline. Build a knowledge pipeline with a content outlet.</blockquote>
      <p>The five trends that matter: YouTube-native AI, self-hosted open source, faceless automation, owned distribution, and technical-creator toolchains. The top-ten picks for the first thirty days come to roughly $85 a month — a lean start with room to grow, and a knowledge layer that compounds no matter which tools survive the year.</p>
    `
  },
  {
    slug: 'webgpu-whisper',
    title: 'Whisper in the Browser: <em>WebGPU</em> Speech Transcription',
    deck: 'Running Whisper on the GPU inside your browser — no upload, no server, no transcript in someone else\u2019s logs. How local speech transcription changes the notes game.',
    category: 'Product',
    tags: ['webgpu', 'whisper', 'local-first', 'privacy', 'speech'],
    date: '2026-05-02',
    readTime: 5,
    glyph: '09',
    art: 'art-9',
    excerpt: 'Speech-to-text on the GPU inside your browser — no upload, no server, no transcript in someone else\u2019s logs.',
    body: `
      <p>There is a moment in every local-first project where you realize the cloud feature you were about to bolt on is actually the whole point. WebGPU Whisper is that moment for Glassy: speech transcription that runs entirely in the browser, on your GPU, with the audio never leaving the machine.</p>
      <h2>Why it matters</h2>
      <p>Voice notes are the fastest way to capture thinking, but the moment transcription requires an upload, the transcript becomes someone else's data. Running Whisper locally inverts that: the recording, the transcription, and the resulting note all stay in your vault. The privacy story is not a feature — it is the architecture.</p>
      <blockquote>The transcript should land in your notes, not in someone else's logs.</blockquote>
      <h2>What WebGPU changed</h2>
      <p>Browser-based ML was always possible; it was just too slow to feel native. WebGPU gave the browser a real compute path to the GPU, and Whisper models that used to crawl now transcribe in something close to real time. The result is a feature that feels like magic and is, underneath, just a well-optimized local pipeline — the same discipline as the rest of the stack: compute stays where the data lives.</p>
      <p>The next steps are the fun ones: speaker labels, auto-tagging, and transcripts that feed the vault's search index the moment they finish. Voice becomes a first-class note format instead of a second-class attachment.</p>
    `
  },
  {
    slug: 'gpu-offloading',
    title: 'GPU Offloading From a Windows Desktop to <em>Proxmox</em>',
    deck: 'The desktop as an inference server the whole mesh can reach: Ollama for the easy path, vLLM for throughput, vLLama for the hybrid, TGI for the Hugging Face ecosystem. A setup walkthrough with real numbers.',
    category: 'Systems',
    tags: ['gpu', 'proxmox', 'infrastructure', 'virtualization'],
    date: '2026-04-14',
    readTime: 7,
    glyph: '10',
    art: 'art-10',
    excerpt: 'Four ways to turn the Windows desktop into the mesh\u2019s inference server — with real throughput numbers.',
    body: `
      <p>Modern GPUs are too expensive to sit idle while you sleep. The project: turn the Windows desktop into an AI inference server that every Proxmox VM and container can reach over the network, so transcription, renders, and model serving run around the clock while the desk stays quiet.</p>
      <h2>Option 1 — Ollama (easiest, recommended to start)</h2>
      <p>Install Ollama, pull the models, bind to all interfaces with <code>OLLAMA_HOST=0.0.0.0:11434</code>, open the port in Windows Firewall — and point everything at the desktop's IP:</p>
      <pre><code>from langchain_ollama import ChatOllama
llm = ChatOllama(
    model="llama3.2",
    base_url="http://192.168.1.188:11434"
)</code></pre>
      <p>Dead simple and works immediately. Not built for high concurrency — fine for development.</p>
      <h2>Option 2 — vLLM (production throughput)</h2>
      <p>vLLM adds continuous batching and PagedAttention memory optimization, which makes it the choice for serving multiple concurrent requests: on the order of <strong>120–160 requests per second with 50–80ms time-to-first-token</strong>. The OpenAI-compatible endpoint means any client just points at the desktop:</p>
      <pre><code>client = OpenAI(
    base_url="http://192.168.1.188:8000/v1",
    api_key="local"
)</code></pre>
      <blockquote>Offloading is not about the hardware. It is about reclaiming the hours.</blockquote>
      <h2>Options 3 and 4 — the hybrids</h2>
      <p><strong>vLLama</strong> combines Ollama's model management with vLLM's speed, loading models on demand and unloading them after five minutes of inactivity — the best of both worlds for a single-GPU desk. <strong>TGI</strong> (Hugging Face's Text Generation Inference) drops in as a Docker container when you want deep Hugging Face ecosystem integration and are willing to pay for the resource weight. Whichever you choose, the pattern is the same: the GPU does the night shift, and the morning finds the renders waiting.</p>
    `
  },
  {
    slug: 'design-vocabulary',
    title: 'Packaging Taste: A <em>Motion-Design Meta-Skill</em>',
    deck: 'Anthropic frontend-design, Impeccable, and LottieFiles motion principles — auto-installed in the right order and exposed as one vocabulary. What "taste as infrastructure" actually looks like.',
    category: 'Craft',
    tags: ['motion', 'design', 'skill', 'taste'],
    date: '2026-03-22',
    readTime: 6,
    glyph: '11',
    art: 'art-11',
    excerpt: 'Three design-vocabulary layers, one auto-installing meta-skill, 46 anti-pattern detectors — taste as infrastructure.',
    body: `
      <p>The hardest thing to give an agent is taste. Models can learn token patterns, but <em>feel</em> — the difference between a transition that lands and one that slides — has to be written down before it can be executed. The design-vocabulary meta-skill is that writing-down: three layers, one auto-installing package.</p>
      <h2>The three layers</h2>
      <ul>
        <li><strong>Layer 1 · Anthropic frontend-design</strong> — 277,000+ installs and the foundation. Commits to a bold aesthetic direction before writing code; avoids generic fonts; develops cohesive color hierarchies; uses motion for polish, not decoration.</li>
        <li><strong>Layer 2 · Impeccable</strong> — Paul Bakaus's Apache-2.0 skill with 10,000+ stars. Its gift is the codified anti-patterns: 46 detectors for exactly the generic-AI defaults — the Inter font, the purple gradient, the nested card.</li>
        <li><strong>Layer 3 · LottieFiles Motion Design</strong> — real animation craft from shipped products, installed via a single command.</li>
      </ul>
      <blockquote>Taste is not a vibe. It is a decision procedure you can write down.</blockquote>
      <h2>Why package it?</h2>
      <p>The meta-skill runs three install commands in the correct order and exposes a unified vocabulary — typography, OKLCH color, spatial, motion, interaction, responsive, UX writing — to any agent that needs non-generic visual output. It is idempotent, safe to invoke repeatedly, and scored a composite 14.0 in the blueprint's evaluation (Impact 4 + Ease 5 + Foundations 5 / Risk 1). The source's verdict is the thesis of this whole blog: <em>great design prompts require design vocabulary. Most people don't have it.</em> Packaging taste as a skill is the natural endgame of the agent-native stack: the same way a render pipeline codifies animation, a skill codifies judgment.</p>
    `
  },
  {
    slug: 'vault-ontology',
    title: 'Vault Ontology: Keeping 5,500 Notes <em>Navigable</em>',
    deck: 'One vault, one git repo, four sources of truth, and a routing tree that has survived five thousand notes. The ontology that keeps a knowledge base from becoming a landfill.',
    category: 'Knowledge',
    tags: ['obsidian', 'ontology', 'notes', 'vault', 'knowledge'],
    date: '2026-02-10',
    readTime: 6,
    glyph: '12',
    art: 'art-12',
    excerpt: 'One vault, one git repo, four sources of truth — the ontology that keeps a knowledge base from becoming a landfill.',
    body: `
      <p>Every knowledge base starts as a clean grid and ends as a landfill unless someone writes the map. The vault ontology is that map — currently keeping 5,500+ notes navigable for both a human and a fleet of agents.</p>
      <h2>The philosophy</h2>
      <p>Four rules anchor everything, and they are worth stealing even at small scale:</p>
      <ul>
        <li><strong>Single vault, single git repo</strong> — no scattered folders across machines pretending to be a system.</li>
        <li><strong>Anti-greenfield</strong> — never re-invent what an existing tool already does; centralize through what is already there.</li>
        <li><strong>Code-as-truth</strong> — codify rules in git and skills, not in agent memory.</li>
        <li><strong>Four sources of truth</strong> — the ontology, the root index, the agent-context index, and the user docs README. If it is not in one of those, it is not authoritative.</li>
      </ul>
      <h2>The routing tree</h2>
      <p>The canonical root routes everything: <code>00_Context</code> for cross-cutting context, <code>02_Projects</code> for active work with a MOC per project, <code>03_Knowledge</code> for knowledge bases, <code>05_Agent_Work</code> for agent artifacts, <code>00_Inbox</code> as the default landing zone for new material. Routing rules are simple: new docs land in the inbox and get triaged; projects get the four-folder spine; skills get a catalog entry with a SKILL.md.</p>
      <blockquote>A vault is not a filing cabinet. It is a city, and the ontology is the street plan.</blockquote>
      <h2>The drift rules</h2>
      <p>Ontologies rot through neglect, so the rules target rot directly: never leave shadow directories when a doc moves — delete the old path; set <code>.gitattributes</code> at init, not after months of CRLF churn; and run md5 directory comparisons because byte-identical duplicates hide for months. The metric that matters is not note count — it is time-to-find. When an agent can pull the right note in seconds, the vault is doing its job.</p>
    `
  }
];

/* Category display order for topic clusters */
window.POZIVERSE.CATEGORIES = [
  { id: 'Signal', kicker: 'Signal', blurb: 'Field reports & transmissions' },
  { id: 'Creation', kicker: 'Creation', blurb: 'Making things with agents' },
  { id: 'Agents', kicker: 'Agents', blurb: 'The fleet & how it runs' },
  { id: 'Systems', kicker: 'Systems', blurb: 'Infrastructure notes' },
  { id: 'Product', kicker: 'Product', blurb: 'Local-first software' },
  { id: 'Craft', kicker: 'Craft', blurb: 'Design & taste' },
  { id: 'Knowledge', kicker: 'Knowledge', blurb: 'Notes on notes' }
];

/* ============================================================
   Broadcast channels (Curated Snapshot Cards — Part V reality
   contract: a static site shows dated snapshots, never live
   platform widgets). Flip status to "live" + add latest to go
   live on a channel.
   ============================================================ */
window.POZIVERSE.SOCIALS = [
  {
    platform: "youtube",
    label: "MAIN UPLINK",
    handle: "@ericpoziverse",
    url: "https://www.youtube.com/@ericpoziverse",
    status: "reserved",              // reserved | dormant | live
    latest: null,                    // { title, date, href } when live
    asOf: "2026-08-27",
    art: "art-1"
  },
  {
    platform: "instagram",
    label: "DAILY FRAGMENTS",
    handle: "@ericpoziverse",
    url: "https://www.instagram.com/ericpoziverse",
    status: "reserved",
    latest: null,
    asOf: "2026-08-27",
    art: "art-2"
  },
  {
    platform: "x",
    label: "OPEN THREADS",
    handle: "@ericpoziverse",
    url: "https://x.com/ericpoziverse",
    status: "reserved",
    latest: null,
    asOf: "2026-08-27",
    art: "art-9"
  },
  {
    platform: "tiktok",
    label: "SHORT BURSTS",
    handle: "@ericpoziverse",
    url: "https://www.tiktok.com/@ericpoziverse",
    status: "reserved",
    latest: null,
    asOf: "2026-08-27",
    art: "art-6"
  }
];

/* ============================================================
   Field Reports (video twins of Transmissions).
   To go live on a video: set youtubeId (the real id) and flip
   status to "live". Until then the page renders the designed
   IN PRODUCTION state — never a broken player.
   ============================================================ */
window.POZIVERSE.VIDEOS = [
  {
    id: "fr-001",
    number: 1,
    youtubeId: null,
    title: 'A Year of Building the <em>Poziverse Mesh</em>',
    deck: 'The video twin of Transmission T-001 — four hosts, one tailnet, and a fleet of agents, on camera from the mesh.',
    category: 'Signal',
    date: '2026-08-27',
    duration: '12:00',
    posterArt: 'art-1',
    glyph: '01',
    chapters: [
      { time: '00:00', label: 'Cold open: the station comes online' },
      { time: '01:20', label: 'The four hosts, on camera' },
      { time: '03:45', label: 'What the agents run themselves' },
      { time: '06:10', label: 'The failures that became runbooks' },
      { time: '09:30', label: 'Year two: what changes' }
    ],
    waveformSeed: 1,
    transcriptUrl: null,
    twinSlug: 'year-of-the-mesh',
    status: 'reserved'               // reserved | live
  }
];

/* ============================================================
   Reply Threads — public peer review of creators we learn from.
   The 7-beat format: Pick, Claim, Praise, Divergence, Receipt,
   Handoff, Thread. Episodes publish only after the fairness
   gate ("would the reviewed creator thank me for this?").
   Until then they render the designed IN COMPOSITION state.
   ============================================================ */
window.POZIVERSE.REPLIES = [
  {
    id: 'rt-001',
    number: 1,
    status: 'in-composition',      // in-composition | live
    date: null,
    creator: null,                 // { name, handle, channelUrl, art } when nominated
    video: null,                   // { title, url, published }
    receipts: [],
    twinSlug: null,
    storyboard: [
      { n: 1, name: 'THE PICK',       text: 'The video that earned a response — and why.' },
      { n: 2, name: 'THE CLAIM',      text: 'Their central idea, restated fairly in our own words.' },
      { n: 3, name: 'THE PRAISE',     text: 'The one move they make brilliantly — timestamped.' },
      { n: 4, name: 'THE DIVERGENCE', text: 'This is what we do instead. From practice, not theory.' },
      { n: 5, name: 'THE RECEIPT',    text: 'Proof of the counter-move: repo, runbook, render.' },
      { n: 6, name: 'THE HANDOFF',    text: 'A generous link back to the creator, plus ours.' },
      { n: 7, name: 'THE THREAD',     text: 'Prior episodes the argument continues from.' }
    ]
  }
];


/* ============================================================
   Downloads (Part V reality contract: real artifacts only;
   versions/licenses real or the row is omitted; closed work
   gets honest states, never dead buttons)
   ============================================================ */
window.POZIVERSE.DOWNLOADS = [
  {
    id: "transmission-log",
    name: "From the Poziverse - Transmission Log",
    kind: "template",
    tagline: "The self-contained site you're reading. One file, zero dependencies.",
    version: "v1.0.0",
    releasedAt: "2026-08-27",
    license: { spdx: "MIT", label: "MIT", url: "" },
    assetUrl: "downloads/transmission-log-template-v1.0.0.zip",
    repoUrl: "",
    demoUrl: "",
    stars: null,
    inside: ["Self-contained index.html (inline CSS/JS/fonts)", "Design tokens, dark + light", "12 CSS art signatures", "RSS feed + template build workflow"],
    receipt: { label: "Shipped with T-001", url: "article.html?id=year-of-the-mesh" },
    featured: true,
    art: "art-1"
  }
];

window.POZIVERSE.CLOSED_MESH = [
  { name: "Glassy", statusLine: "Neurodiversity-focused AI workspace - public build on the roadmap" },
  { name: "OpenMontage", statusLine: "Agentic video production system - capability review in progress" },
  { name: "Mission Control", statusLine: "The operations floor for the mesh - it runs the mesh, so it stays in the mesh" }
];

/* ============================================================
   The Library (prompt / skill / blueprint shelf)
   ============================================================ */
window.POZIVERSE.LIBRARY = [
  {
    id: "editorial-response",
    title: "Editorial Response",
    kind: "skill",
    summary: "The 7-beat public peer-review structure behind Reply Threads. Fairness gate, fixed beats, receipt rule - packaged as a reusable instruction.",
    body: "You are an editorial responder for From the Poziverse. You write public peer reviews of videos by creators you learn from - fairly, generously, with receipts. You are not a reaction channel. You are peer review, published.\n\nTHE FAIRNESS GATE (run before writing): 1. Would the reviewed creator plausibly thank me for this piece? 2. Is my divergence grounded in practice - something I actually built or ran? 3. Am I linking the original in the first two lines? If any answer is no: stop, rework, or drop the episode.\n\nTHE 7 BEATS: (1) THE PICK - name the creator, the video, why it earned a response; two lines max; the pick is a compliment. (2) THE CLAIM - restate their central idea fairly, as a quote with attribution; if they would not endorse your restatement, rewatch. (3) THE PRAISE - the specific move they make brilliantly, with at least one timestamped reference; specificity is respect. (4) THE DIVERGENCE - 'this is what I do instead'; grounded in your own practice, never hypothetical, never a takedown; this beat carries the piece. (5) THE RECEIPT - proof of the divergence: repo, runbook, render, screenshot; no receipt, no divergence. (6) THE HANDOFF - a generous link to the creator's channel plus your related piece. (7) THE THREAD - two or three prior episodes the argument continues from.\n\nFORMAT RULES: text-first; if a video variant ships, clips are short, timestamped, critique-proportionate. Voice: engineer-poet - concise, confident, concrete. The divergence is always 'what I do instead,' never 'what they should have done.' Publish with a right-of-reply note in The Thread.",
    version: "v1.0.0",
    updated: "2026-08-27",
    license: { spdx: "CC BY-SA 4.0", label: "CC BY-SA 4.0", url: "" },
    status: "published",
    provenance: ["SOURCE: vault - capability layer", "TENANT: EricPoziverse", "FIRST CONSUMER: this blog"],
    receipt: { label: "RT-001 run of show", url: "replies.html" },
    featured: true,
    art: "art-3"
  }
];

/* ============================================================
   Now (the indie-web heartbeat)
   ============================================================ */
window.POZIVERSE.NOW = {
  updated: "2026-08-27",
  staleAfterDays: 45,
  project: {
    title: "The media center build-out",
    status: "RUNNING",
    since: "2026-08-04",
    notes: [
      { date: "2026-08-27", text: "Broadcast strip + Watch shipped; Reply Threads format designed and staged." },
      { date: "2026-08-26", text: "Experience blueprint completed: motion system, six surface specs, reality contracts." },
      { date: "2026-08-20", text: "Atlas deployed to the shared origin; vault ingest at 5,519 notes." }
    ],
    link: "downloads.html",
    receipt: null
  },
  read: {
    title: "The Elements of Typographic Style",
    author: "Robert Bringhurst",
    why: "The 25th-anniversary edition - because uptime is typography and the uppercase tracking rule has a page number.",
    link: "",
    progress: null
  },
  experiment: {
    title: "Agent-native section headers",
    hypothesis: "A HyperFrames render pipeline can produce every section header for the channel from one brand spec - no manual keyframing.",
    stack: ["HyperFrames", "Manim", "Hermes"],
    status: "RUNNING",
    link: "article.html?id=agent-native-video",
    receipt: null
  },
  archive: [
    { month: "2026-08", line: "shipped the media center: broadcast strip, watch page, reply threads" },
    { month: "2026-07", line: "closed the loop on LLM routing + the quota watchdog pattern" },
    { month: "2026-06", line: "designed Mission Control's locked chrome and dual-location deploys" }
  ]
};
